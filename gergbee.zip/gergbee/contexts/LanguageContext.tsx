'use client';

import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

type Language = 'pt' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  pt: {
    // Navigation
    'nav.home': 'Início',
    'nav.solutions': 'Soluções',
    'nav.pricing': 'Preços',
    'nav.differentials': 'Diferenciais',
    'nav.resources': 'Recursos',
    'nav.blog': 'Blog',
    'nav.docs': 'Documentação',
    'nav.community': 'Comunidade',
    'nav.login': 'Login',
    'nav.signup': 'Comece Agora',
    
    // Solutions submenu
    'nav.cloudvps': 'Cloud VPS',
    'nav.managed': 'Hospedagem Gerenciada',
    'nav.dedicated': 'Servidores Dedicados',
    'nav.apps': 'Hospedagem de Aplicações',
    
    // Hero
    'hero.badge': 'Performance 3x Superior',
    'hero.title': 'Hospedagem Cloud de',
    'hero.titleHighlight': 'Alta Performance',
    'hero.titleEnd': 'no Brasil',
    'hero.subtitle': 'Implante sua infraestrutura cloud em 55 segundos. Garantia de uptime de 99.99%, suporte 24/7 em português e migração gratuita.',
    'hero.stat1': 'Uptime',
    'hero.stat2': 'Suporte',
    'hero.stat3': 'Mais Rápido',
    'hero.cta.primary': 'Começar Gratuitamente',
    'hero.cta.secondary': 'Ver Preços',
    
    // Features
    'features.title1': 'Tudo que você precisa para',
    'features.title2': 'dominar a nuvem',
    'features.subtitle': 'Recursos enterprise a preços acessíveis. Sem letras miúdas, sem taxas ocultas.',
    
    // Performance
    'perf.title1': 'Performance que',
    'perf.title2': 'impressiona',
    'perf.subtitle': 'Comparação direta com os principais concorrentes usando ferramentas padrão da indústria.',
    
    // Testimonials
    'testimonials.title1': 'Amado por',
    'testimonials.title2': 'desenvolvedores',
    'testimonials.subtitle': 'Mais de 5.000 clientes confiam na Quark Cloud para hospedar suas aplicações críticas.',
    
    // CTA
    'cta.badge': 'Comece Hoje Gratuitamente',
    'cta.title1': 'Pronto para',
    'cta.title2': 'decolar',
    'cta.subtitle': 'Junte-se a milhares de desenvolvedores e empresas que confiam na Quark Cloud. Crie sua conta em menos de 1 minuto e ganhe',
    'cta.credits': '$100 em créditos',
    'cta.credits2': 'para testar.',
    'cta.btn1': 'Criar Conta Gratuita',
    'cta.btn2': 'Falar com Vendas',
    'cta.benefit1': 'Sem cartão de crédito',
    'cta.benefit2': '$100 em créditos grátis',
    'cta.benefit3': 'Deploy em 55 segundos',
    
    // Common
    'common.learnMore': 'Saiba Mais',
    'common.getStarted': 'Começar Agora',
    'common.contact': 'Entrar em Contato',
    'common.startFree': 'Começar Gratuitamente',
    'common.viewPricing': 'Ver Preços',
  },
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.solutions': 'Solutions',
    'nav.pricing': 'Pricing',
    'nav.differentials': 'Why Us',
    'nav.resources': 'Resources',
    'nav.blog': 'Blog',
    'nav.docs': 'Documentation',
    'nav.community': 'Community',
    'nav.login': 'Login',
    'nav.signup': 'Get Started',
    
    // Solutions submenu
    'nav.cloudvps': 'Cloud VPS',
    'nav.managed': 'Managed Hosting',
    'nav.dedicated': 'Dedicated Servers',
    'nav.apps': 'App Hosting',
    
    // Hero
    'hero.badge': '3x Superior Performance',
    'hero.title': 'High-Performance',
    'hero.titleHighlight': 'Cloud Hosting',
    'hero.titleEnd': 'in Brazil',
    'hero.subtitle': 'Deploy your cloud infrastructure in 55 seconds. 99.99% uptime guarantee, 24/7 support in Portuguese, and free migration.',
    'hero.stat1': 'Uptime',
    'hero.stat2': 'Support',
    'hero.stat3': 'Faster',
    'hero.cta.primary': 'Start Free',
    'hero.cta.secondary': 'View Pricing',
    
    // Features
    'features.title1': 'Everything you need to',
    'features.title2': 'master the cloud',
    'features.subtitle': 'Enterprise features at affordable prices. No fine print, no hidden fees.',
    
    // Performance
    'perf.title1': 'Performance that',
    'perf.title2': 'impresses',
    'perf.subtitle': 'Direct comparison with top competitors using industry-standard tools.',
    
    // Testimonials
    'testimonials.title1': 'Loved by',
    'testimonials.title2': 'developers',
    'testimonials.subtitle': 'Over 5,000 customers trust Quark Cloud to host their mission-critical applications.',
    
    // CTA
    'cta.badge': 'Start Free Today',
    'cta.title1': 'Ready to',
    'cta.title2': 'take off',
    'cta.subtitle': 'Join thousands of developers and companies who trust Quark Cloud. Create your account in less than 1 minute and get',
    'cta.credits': '$100 in credits',
    'cta.credits2': 'to test.',
    'cta.btn1': 'Create Free Account',
    'cta.btn2': 'Talk to Sales',
    'cta.benefit1': 'No credit card required',
    'cta.benefit2': '$100 in free credits',
    'cta.benefit3': 'Deploy in 55 seconds',
    
    // Common
    'common.learnMore': 'Learn More',
    'common.getStarted': 'Get Started',
    'common.contact': 'Contact Us',
    'common.startFree': 'Start Free',
    'common.viewPricing': 'View Pricing',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>('pt');

  useEffect(() => {
    const savedLang = localStorage.getItem('language') as Language | null;
    if (savedLang) {
      setLanguageState(savedLang);
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('language', lang);
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.pt] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

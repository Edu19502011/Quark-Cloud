'use client';

import Link from 'next/link';
import { ArrowRight, Zap, Shield, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';

export function Hero() {
  const { t } = useLanguage();
  return (
    <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-900/20 via-gray-950 to-gray-950" />
      
      {/* Animated grid background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.02)_1px,transparent_1px)] bg-[size:72px_72px]" />

      <div className="relative max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Badge */}
            <div className="inline-flex items-center space-x-2 bg-primary-500/10 border border-primary-500/20 rounded-full px-4 py-2 mb-6">
              <Zap className="w-4 h-4 text-primary-400" />
              <span className="text-sm text-primary-300 font-medium">
                {t('hero.badge')}
              </span>
            </div>

            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              {t('hero.title')}{' '}
              <span className="gradient-text">{t('hero.titleHighlight')}</span>{' '}
              {t('hero.titleEnd')}
            </h1>

            <p className="text-xl text-gray-400 mb-8 leading-relaxed">
              {t('hero.subtitle')}
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              <div>
                <div className="text-3xl font-bold text-white mb-1">99.99%</div>
                <div className="text-sm text-gray-400">{t('hero.stat1')}</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">5min</div>
                <div className="text-sm text-gray-400">{t('hero.stat2')}</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">3x</div>
                <div className="text-sm text-gray-400">{t('hero.stat3')}</div>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/signup"
                className="group inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:shadow-xl hover:shadow-primary-500/50"
              >
                {t('hero.cta.primary')}
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/precos"
                className="inline-flex items-center justify-center border border-gray-700 hover:border-gray-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:bg-gray-900"
              >
                {t('hero.cta.secondary')}
              </Link>
            </div>

            {/* Trust badges */}
            <div className="mt-8 flex items-center space-x-6 text-sm text-gray-400">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-green-500" />
                <span>Certificado ISO 27001</span>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-primary-400" />
                <span>+5.000 Clientes</span>
              </div>
            </div>
          </motion.div>

          {/* Right content - Terminal Preview */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="hidden lg:block"
          >
            <div className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden shadow-2xl">
              {/* Terminal header */}
              <div className="bg-gray-800 px-4 py-3 flex items-center space-x-2">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full" />
                  <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                  <div className="w-3 h-3 bg-green-500 rounded-full" />
                </div>
                <div className="text-gray-400 text-sm ml-4">bash</div>
              </div>
              {/* Terminal content */}
              <div className="p-6 font-mono text-sm">
                <div className="text-green-400">$ gergbee create vm</div>
                <div className="text-gray-400 mt-2">Creating VM instance...</div>
                <div className="text-gray-400">✓ Allocating resources</div>
                <div className="text-gray-400">✓ Configuring network</div>
                <div className="text-gray-400">✓ Installing OS</div>
                <div className="text-primary-400 mt-2 font-semibold">
                  ✓ VM created successfully in 55s
                </div>
                <div className="text-gray-400 mt-4">
                  IP: <span className="text-white">203.0.113.42</span>
                </div>
                <div className="text-gray-400">
                  Status: <span className="text-green-400">Running</span>
                </div>
                <div className="text-gray-400 mt-4 flex items-center">
                  <span className="animate-pulse mr-2">▊</span>
                  Ready to deploy
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

'use client';

import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

export function Testimonials() {
  const testimonials = [
    {
      name: 'Carlos Eduardo',
      role: 'CTO @ TechStartup',
      company: 'São Paulo, SP',
      content: 'Migramos toda nossa infraestrutura para a Quark Cloud e vimos uma redução de 40% nos custos com performance 3x superior. O suporte em português é excepcional.',
      rating: 5,
      avatar: 'CE',
    },
    {
      name: 'Mariana Silva',
      role: 'DevOps Engineer',
      company: 'Rio de Janeiro, RJ',
      content: 'A velocidade de deploy é impressionante. Em menos de 1 minuto consigo subir ambientes completos. A API é muito bem documentada e o painel é intuitivo.',
      rating: 5,
      avatar: 'MS',
    },
    {
      name: 'Rafael Costa',
      role: 'Founder @ E-commerce',
      company: 'Belo Horizonte, MG',
      content: 'Migração gratuita e zero downtime. A equipe é extremamente competente. Nunca tive um suporte tão rápido - média de 3 minutos de resposta!',
      rating: 5,
      avatar: 'RC',
    },
    {
      name: 'Ana Paula Oliveira',
      role: 'Agência Digital',
      company: 'Curitiba, PR',
      content: 'Hospedamos mais de 50 sites WordPress de clientes. A hospedagem gerenciada é perfeita - backups automáticos, atualizações e segurança inclusos.',
      rating: 5,
      avatar: 'AO',
    },
    {
      name: 'Bruno Martins',
      role: 'Lead Developer',
      company: 'Porto Alegre, RS',
      content: 'Escalabilidade sem downtime é um game changer. Conseguimos lidar com picos de tráfego sem preocupação. Performance consistente 24/7.',
      rating: 5,
      avatar: 'BM',
    },
    {
      name: 'Juliana Santos',
      role: 'SysAdmin',
      company: 'Brasília, DF',
      content: 'A garantia de SLA de 99.99% não é marketing - é real. Em 18 meses nunca tivemos um incidente. Confiabilidade total para ambientes críticos.',
      rating: 5,
      avatar: 'JS',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Amado por{' '}
            <span className="gradient-text">desenvolvedores</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Mais de 5.000 clientes confiam na Quark Cloud para hospedar suas aplicações críticas.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {testimonials.map((testimonial) => (
            <motion.div
              key={testimonial.name}
              variants={itemVariants}
              className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300 relative"
            >
              <Quote className="absolute top-4 right-4 w-8 h-8 text-gray-800" />
              
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center text-white font-bold">
                  {testimonial.avatar}
                </div>
                <div>
                  <div className="font-semibold text-white">{testimonial.name}</div>
                  <div className="text-sm text-gray-400">{testimonial.role}</div>
                  <div className="text-xs text-gray-500">{testimonial.company}</div>
                </div>
              </div>

              <div className="flex space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              <p className="text-gray-300 text-sm leading-relaxed">
                "{testimonial.content}"
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* Trust Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">5.000+</div>
            <div className="text-gray-400">Clientes Ativos</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">98%</div>
            <div className="text-gray-400">Taxa de Satisfação</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">15K+</div>
            <div className="text-gray-400">VMs Gerenciadas</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">4.9/5</div>
            <div className="text-gray-400">Avaliação Média</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

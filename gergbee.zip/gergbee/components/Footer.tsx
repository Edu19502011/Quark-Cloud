'use client';

import Link from 'next/link';
import { Cloud, Github, Twitter, Linkedin, Mail } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    solutions: [
      { name: 'Cloud VPS', href: '/solucoes/cloud-vps' },
      { name: 'Hospedagem Gerenciada', href: '/solucoes/hospedagem-gerenciada' },
      { name: 'Servidores Dedicados', href: '/solucoes/servidores-dedicados' },
      { name: 'Hospedagem de Aplicações', href: '/solucoes/aplicacoes' },
    ],
    resources: [
      { name: 'Documentação', href: '/docs' },
      { name: 'Blog', href: '/blog' },
      { name: 'Comunidade', href: '/comunidade' },
      { name: 'Status', href: '/status' },
    ],
    company: [
      { name: 'Sobre', href: '/sobre' },
      { name: 'Diferenciais', href: '/diferenciais' },
      { name: 'Carreiras', href: '/carreiras' },
      { name: 'Contato', href: '/contato' },
    ],
    legal: [
      { name: 'Termos de Uso', href: '/termos' },
      { name: 'Privacidade', href: '/privacidade' },
      { name: 'SLA', href: '/sla' },
    ],
  };

  return (
    <footer className="bg-gray-950 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <Cloud className="w-8 h-8 text-primary-400" />
              <span className="text-lg font-bold gradient-text">Quark Cloud</span>
            </Link>
            <p className="text-gray-400 text-sm mb-4">
              Hospedagem Cloud de Alta Performance no Brasil. Implante em 55 segundos.
            </p>
            <div className="flex space-x-4">
              <a href="https://github.com" className="text-gray-400 hover:text-white transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="https://twitter.com" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="https://linkedin.com" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="mailto:contato@gergbee.cloud" className="text-gray-400 hover:text-white transition-colors">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Solutions */}
          <div>
            <h3 className="text-white font-semibold mb-4">Soluções</h3>
            <ul className="space-y-2">
              {footerLinks.solutions.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-white font-semibold mb-4">Recursos</h3>
            <ul className="space-y-2">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-white font-semibold mb-4">Empresa</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © {currentYear} Quark Cloud. Todos os direitos reservados.
          </p>
          <p className="text-gray-400 text-sm mt-4 md:mt-0">
            Uptime de 99.99% garantido • Suporte 24/7 em português
          </p>
        </div>
      </div>
    </footer>
  );
}

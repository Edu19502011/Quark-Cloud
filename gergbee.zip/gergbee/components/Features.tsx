'use client';

import { motion } from 'framer-motion';
import { 
  Zap, 
  Shield, 
  Globe, 
  HeadphonesIcon, 
  Database, 
  Lock,
  Gauge,
  Workflow,
  Cloud
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function Features() {
  const { t } = useLanguage();
  const features = [
    {
      icon: Zap,
      title: 'Performance Extrema',
      description: 'SSDs NVMe de última geração e processadores AMD EPYC para I/O 3x mais rápido que a concorrência.',
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
    },
    {
      icon: Shield,
      title: 'Segurança Avançada',
      description: 'Proteção DDoS incluída, firewall configurável e backups automáticos diários com retenção de 30 dias.',
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
    },
    {
      icon: Globe,
      title: 'Rede Global',
      description: 'Data centers no Brasil, EUA e Europa com latência ultra-baixa e 10 Gbps de conectividade.',
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
    },
    {
      icon: HeadphonesIcon,
      title: 'Suporte 24/7 em Português',
      description: 'Time técnico especializado com tempo médio de resposta de 5 minutos via chat, ticket ou telefone.',
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
    },
    {
      icon: Database,
      title: 'Escalabilidade Instantânea',
      description: 'Escale CPU, RAM e disco sem downtime. De 1 vCore a 64 vCores, de 1GB a 512GB de RAM.',
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-400/10',
    },
    {
      icon: Lock,
      title: 'Conformidade Total',
      description: 'Certificações ISO 27001, SOC 2 Type II e LGPD. Seus dados seguros e em conformidade.',
      color: 'text-red-400',
      bgColor: 'bg-red-400/10',
    },
    {
      icon: Gauge,
      title: 'Deploy em 55 Segundos',
      description: 'Infraestrutura pronta para produção em menos de 1 minuto. API completa e CLI moderno.',
      color: 'text-orange-400',
      bgColor: 'bg-orange-400/10',
    },
    {
      icon: Workflow,
      title: 'Migração Gratuita',
      description: 'Nossa equipe migra seus servidores gratuitamente, sem custo adicional e com zero downtime.',
      color: 'text-pink-400',
      bgColor: 'bg-pink-400/10',
    },
    {
      icon: Cloud,
      title: 'Painel Intuitivo',
      description: 'Interface moderna e responsiva. Gerencie toda sua infraestrutura em um só lugar.',
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-400/10',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            {t('features.title1')}{' '}
            <span className="gradient-text">{t('features.title2')}</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            {t('features.subtitle')}
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                variants={itemVariants}
                className="group bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300 hover:shadow-xl hover:shadow-primary-500/5"
              >
                <div className={`${feature.bgColor} w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`w-6 h-6 ${feature.color}`} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-400">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}

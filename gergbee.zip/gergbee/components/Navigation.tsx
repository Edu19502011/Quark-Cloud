'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, X, Cloud, Sun, Moon, Globe } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';
import { useLanguage } from '@/contexts/LanguageContext';

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<'dark' | 'light'>('dark');
  const [currentLang, setCurrentLang] = useState<'pt' | 'en'>('pt');

  let themeContext: ReturnType<typeof useTheme> | null = null;
  let langContext: ReturnType<typeof useLanguage> | null = null;
  
  try {
    themeContext = useTheme();
    langContext = useLanguage();
  } catch (e) {
    // Context not available during SSR
  }

  useEffect(() => {
    setMounted(true);
    if (themeContext) {
      setCurrentTheme(themeContext.theme);
    }
    if (langContext) {
      setCurrentLang(langContext.language);
    }
  }, [themeContext, langContext]);

  const handleThemeToggle = () => {
    if (themeContext) {
      themeContext.toggleTheme();
      setCurrentTheme(themeContext.theme === 'dark' ? 'light' : 'dark');
    }
  };

  const handleLangToggle = () => {
    if (langContext) {
      const newLang = langContext.language === 'pt' ? 'en' : 'pt';
      langContext.setLanguage(newLang);
      setCurrentLang(newLang);
    }
  };

  const navItems = [
    { name: langContext?.t('nav.home') || 'Início', href: '/' },
    {
      name: langContext?.t('nav.solutions') || 'Soluções',
      href: '/solucoes',
      submenu: [
        { name: langContext?.t('nav.cloudvps') || 'Cloud VPS', href: '/solucoes/cloud-vps' },
        { name: langContext?.t('nav.managed') || 'Hospedagem Gerenciada', href: '/solucoes/hospedagem-gerenciada' },
        { name: langContext?.t('nav.dedicated') || 'Servidores Dedicados', href: '/solucoes/servidores-dedicados' },
        { name: langContext?.t('nav.apps') || 'Hospedagem de Aplicações', href: '/solucoes/aplicacoes' },
      ],
    },
    { name: langContext?.t('nav.pricing') || 'Preços', href: '/precos' },
    { name: langContext?.t('nav.differentials') || 'Diferenciais', href: '/diferenciais' },
    {
      name: langContext?.t('nav.resources') || 'Recursos',
      href: '/recursos',
      submenu: [
        { name: langContext?.t('nav.blog') || 'Blog', href: '/blog' },
        { name: langContext?.t('nav.docs') || 'Documentação', href: '/docs' },
        { name: langContext?.t('nav.community') || 'Comunidade', href: '/comunidade' },
      ],
    },
  ];

  return (
    <nav className="fixed w-full z-50 bg-white/80 dark:bg-gray-950/80 backdrop-blur-lg border-b border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 group">
            <Cloud className="w-8 h-8 text-primary-400 group-hover:text-primary-300 transition-colors" />
            <span className="text-xl font-bold gradient-text">Quark Cloud</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <div key={item.name} className="relative group">
                <Link
                  href={item.href}
                  className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors py-2"
                >
                  {item.name}
                </Link>
                {item.submenu && (
                  <div className="absolute top-full left-0 mt-2 w-64 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                    {item.submenu.map((subitem) => (
                      <Link
                        key={subitem.name}
                        href={subitem.href}
                        className="block px-4 py-3 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 first:rounded-t-lg last:rounded-b-lg transition-colors"
                      >
                        {subitem.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Language Toggle */}
            <button
              onClick={handleLangToggle}
              className="flex items-center space-x-1 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
              title="Change Language"
            >
              <Globe className="w-5 h-5" />
              <span className="text-sm font-medium">{currentLang.toUpperCase()}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={handleThemeToggle}
              className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
              title="Toggle Theme"
            >
              {currentTheme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            <Link
              href="/login"
              className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              {langContext?.t('nav.login') || 'Login'}
            </Link>
            <Link
              href="/signup"
              className="bg-primary-500 hover:bg-primary-600 text-white px-6 py-2 rounded-lg font-medium transition-all duration-200 hover:shadow-lg hover:shadow-primary-500/50"
            >
              {langContext?.t('nav.signup') || 'Comece Agora'}
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-2">
            {/* Mobile Theme Toggle */}
            <button
              onClick={handleThemeToggle}
              className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              {currentTheme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            
            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
          <div className="px-4 pt-2 pb-4 space-y-2">
            {navItems.map((item) => (
              <div key={item.name}>
                <Link
                  href={item.href}
                  className="block py-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  {item.name}
                </Link>
                {item.submenu && (
                  <div className="pl-4 space-y-2">
                    {item.submenu.map((subitem) => (
                      <Link
                        key={subitem.name}
                        href={subitem.href}
                        className="block py-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm"
                        onClick={() => setIsOpen(false)}
                      >
                        {subitem.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-4 space-y-2">
              <Link
                href="/login"
                className="block py-2 text-center text-gray-300 hover:text-white border border-gray-700 rounded-lg transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {langContext?.t('nav.login') || 'Login'}
              </Link>
              <Link
                href="/signup"
                className="block py-2 text-center bg-primary-500 text-white rounded-lg font-medium"
                onClick={() => setIsOpen(false)}
              >
                {langContext?.t('nav.signup') || 'Comece Agora'}
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

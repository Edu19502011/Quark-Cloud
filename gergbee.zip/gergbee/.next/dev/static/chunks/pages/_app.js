__turbopack_load_page_chunks__("/_app", [
  "static/chunks/1d6ff_next_dist_compiled_a96bac57._.js",
  "static/chunks/1d6ff_next_dist_shared_lib_20a278b9._.js",
  "static/chunks/1d6ff_next_dist_client_42b6177d._.js",
  "static/chunks/1d6ff_next_dist_75a6b97f._.js",
  "static/chunks/1d6ff_next_app_106469da.js",
  "static/chunks/[next]_entry_page-loader_ts_5ae339e0._.js",
  "static/chunks/1d6ff_react-dom_1d1610d3._.js",
  "static/chunks/1d6ff_18c0480d._.js",
  "static/chunks/[root-of-the-server]__d7a71002._.js",
  "static/chunks/Downloads_gergbee_pages__app_2da965e7._.js",
  "static/chunks/turbopack-Downloads_gergbee_pages__app_34b059b0._.js"
])

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_a31555ec._.js",
  "static/chunks/Downloads_gergbee_app_solucoes_servidores-dedicados_page_tsx_dcd9e57a._.js"
],
    source: "dynamic"
});

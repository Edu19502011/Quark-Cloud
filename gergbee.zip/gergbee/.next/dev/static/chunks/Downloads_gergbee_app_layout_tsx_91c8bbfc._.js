(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Downloads_gergbee_app_globals_5dc31d78.css",
  "static/chunks/Downloads_gergbee_4f43dc6b._.js"
],
    source: "dynamic"
});

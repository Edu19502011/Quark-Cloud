(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_85d7f2ae._.js",
  "static/chunks/Downloads_gergbee_app_diferenciais_page_tsx_680e3660._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_7e153de6._.js",
  "static/chunks/Downloads_gergbee_app_comunidade_page_tsx_67027d97._.js"
],
    source: "dynamic"
});

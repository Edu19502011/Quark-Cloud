(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_c90dffd9._.js",
  "static/chunks/Downloads_gergbee_app_solucoes_aplicacoes_page_tsx_a06de4e3._.js"
],
    source: "dynamic"
});

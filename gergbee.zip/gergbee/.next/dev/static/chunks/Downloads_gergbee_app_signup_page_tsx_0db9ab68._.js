(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_092bc4c7._.js",
  "static/chunks/Downloads_gergbee_app_signup_page_tsx_6b3e3173._.js"
],
    source: "dynamic"
});

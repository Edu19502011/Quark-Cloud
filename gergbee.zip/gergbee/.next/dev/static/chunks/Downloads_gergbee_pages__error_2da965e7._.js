(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_next_dist_compiled_a96bac57._.js",
  "static/chunks/1d6ff_next_dist_shared_lib_b1d96ce7._.js",
  "static/chunks/1d6ff_next_dist_client_42b6177d._.js",
  "static/chunks/1d6ff_next_dist_0ef3bf81._.js",
  "static/chunks/1d6ff_next_error_16419b4e.js",
  "static/chunks/[next]_entry_page-loader_ts_b58f4b09._.js",
  "static/chunks/1d6ff_react-dom_1d1610d3._.js",
  "static/chunks/1d6ff_18c0480d._.js",
  "static/chunks/[root-of-the-server]__f5504bb8._.js"
],
    source: "entry"
});

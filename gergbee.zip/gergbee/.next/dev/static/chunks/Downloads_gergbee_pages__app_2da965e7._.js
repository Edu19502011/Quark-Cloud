(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_next_dist_compiled_a96bac57._.js",
  "static/chunks/1d6ff_next_dist_shared_lib_20a278b9._.js",
  "static/chunks/1d6ff_next_dist_client_42b6177d._.js",
  "static/chunks/1d6ff_next_dist_75a6b97f._.js",
  "static/chunks/1d6ff_next_app_106469da.js",
  "static/chunks/[next]_entry_page-loader_ts_5ae339e0._.js",
  "static/chunks/1d6ff_react-dom_1d1610d3._.js",
  "static/chunks/1d6ff_18c0480d._.js",
  "static/chunks/[root-of-the-server]__d7a71002._.js"
],
    source: "entry"
});

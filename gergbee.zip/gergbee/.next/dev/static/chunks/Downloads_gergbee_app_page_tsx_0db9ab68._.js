(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Downloads_gergbee_components_3f8c2f0a._.js",
  "static/chunks/1d6ff_0d7aa485._.js"
],
    source: "dynamic"
});

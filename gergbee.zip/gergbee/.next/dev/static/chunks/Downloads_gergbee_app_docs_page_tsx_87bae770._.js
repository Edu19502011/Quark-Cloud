(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_cc3a99ce._.js",
  "static/chunks/Downloads_gergbee_app_docs_page_tsx_5515d83f._.js"
],
    source: "dynamic"
});

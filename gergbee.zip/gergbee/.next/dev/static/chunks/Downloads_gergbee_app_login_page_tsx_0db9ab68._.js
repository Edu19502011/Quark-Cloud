(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_5276c0a7._.js",
  "static/chunks/Downloads_gergbee_app_login_page_tsx_6e5e69ca._.js"
],
    source: "dynamic"
});

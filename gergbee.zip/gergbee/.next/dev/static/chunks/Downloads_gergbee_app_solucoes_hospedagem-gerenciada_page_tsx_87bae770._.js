(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1d6ff_70d4374c._.js",
  "static/chunks/Downloads_gergbee_app_solucoes_hospedagem-gerenciada_page_tsx_51179ff0._.js"
],
    source: "dynamic"
});

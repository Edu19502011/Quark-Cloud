(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1e9f4af6._.js",
  "static/chunks/1d6ff_next_dist_compiled_react-dom_35636f27._.js",
  "static/chunks/1d6ff_next_dist_compiled_react-server-dom-turbopack_2724a921._.js",
  "static/chunks/1d6ff_next_dist_compiled_next-devtools_index_2e2033fe.js",
  "static/chunks/1d6ff_next_dist_compiled_0ac0b0b1._.js",
  "static/chunks/1d6ff_next_dist_client_3ede3dac._.js",
  "static/chunks/1d6ff_next_dist_918b6f8d._.js",
  "static/chunks/1d6ff_@swc_helpers_cjs_b1799ab7._.js"
],
    source: "entry"
});

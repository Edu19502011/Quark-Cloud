globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/1d6ff_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1e9f4af6._.js",
    "static/chunks/1d6ff_next_dist_compiled_react-dom_35636f27._.js",
    "static/chunks/1d6ff_next_dist_compiled_react-server-dom-turbopack_2724a921._.js",
    "static/chunks/1d6ff_next_dist_compiled_next-devtools_index_2e2033fe.js",
    "static/chunks/1d6ff_next_dist_compiled_0ac0b0b1._.js",
    "static/chunks/1d6ff_next_dist_client_3ede3dac._.js",
    "static/chunks/1d6ff_next_dist_918b6f8d._.js",
    "static/chunks/1d6ff_@swc_helpers_cjs_b1799ab7._.js",
    "static/chunks/Downloads_gergbee_a0ff3932._.js",
    "static/chunks/turbopack-Downloads_gergbee_9be32ac2._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];
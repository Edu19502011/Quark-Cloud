var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/1d6ff_dbdf930e._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/Downloads/gergbee/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Downloads/gergbee/node_modules/next/document.js [ssr] (ecmascript)").exports

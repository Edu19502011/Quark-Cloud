module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/precos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Downloads_gergbee__next-internal_server_app_precos_page_actions_fd1a741b.js.map
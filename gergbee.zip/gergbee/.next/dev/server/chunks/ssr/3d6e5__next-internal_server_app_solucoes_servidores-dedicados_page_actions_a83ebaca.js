module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/solucoes/servidores-dedicados/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d6e5__next-internal_server_app_solucoes_servidores-dedicados_page_actions_a83ebaca.js.map
module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/diferenciais/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Downloads_gergbee__next-internal_server_app_diferenciais_page_actions_4918a816.js.map
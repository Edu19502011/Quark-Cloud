module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/solucoes/aplicacoes/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6c7f9_gergbee__next-internal_server_app_solucoes_aplicacoes_page_actions_e1604a41.js.map
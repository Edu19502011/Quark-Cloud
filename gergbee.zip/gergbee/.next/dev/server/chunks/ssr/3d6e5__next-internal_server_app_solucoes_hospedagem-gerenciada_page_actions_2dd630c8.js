module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/solucoes/hospedagem-gerenciada/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d6e5__next-internal_server_app_solucoes_hospedagem-gerenciada_page_actions_2dd630c8.js.map
module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/signup/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Downloads_gergbee__next-internal_server_app_signup_page_actions_b6d6ec08.js.map
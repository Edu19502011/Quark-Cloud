module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/blog/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Downloads_gergbee__next-internal_server_app_blog_page_actions_432a5e8b.js.map
module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/comunidade/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Downloads_gergbee__next-internal_server_app_comunidade_page_actions_e8d3043d.js.map
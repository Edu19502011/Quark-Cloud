module.exports = [
"[project]/Downloads/gergbee/.next-internal/server/app/solucoes/cloud-vps/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6c7f9_gergbee__next-internal_server_app_solucoes_cloud-vps_page_actions_9ab28f4b.js.map
'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Book, Search, Code, Server, Database, Shield } from 'lucide-react';

export default function DocsPage() {
  const sections = [
    { icon: Code, title: 'Guia de Início Rápido', desc: 'Primeiros passos com a Quark Cloud', link: '#' },
    { icon: Server, title: 'API Reference', desc: 'Documentação completa da API REST', link: '#' },
    { icon: Database, title: 'Banco de Dados', desc: 'PostgreSQL, MySQL, MongoDB', link: '#' },
    { icon: Shield, title: 'Segurança', desc: 'Melhores práticas de segurança', link: '#' },
  ];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-white">
            <span className="gradient-text">Documentação</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-8">
            Guias, tutoriais e referências completas para você aproveitar ao máximo a Quark Cloud.
          </p>
          
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar na documentação..."
                className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg pl-12 pr-4 py-4 text-gray-900 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {sections.map((section) => (
            <Link
              key={section.title}
              href={section.link}
              className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6 hover:border-primary-500/50 transition-all"
            >
              <section.icon className="w-10 h-10 text-primary-400 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{section.title}</h3>
              <p className="text-gray-600 dark:text-gray-400">{section.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

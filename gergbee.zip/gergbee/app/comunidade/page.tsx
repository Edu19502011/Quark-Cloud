'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { MessageSquare, Github, Twitter, Users, HelpCircle } from 'lucide-react';

export default function ComunidadePage() {
  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-white">
            <span className="gradient-text">Comunidade</span> Quark Cloud
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Conecte-se com milhares de desenvolvedores, compartilhe conhecimento e tire dúvidas.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            { icon: MessageSquare, title: 'Discord', desc: 'Chat em tempo real com a comunidade', link: '#', color: 'text-purple-400' },
            { icon: Github, title: 'GitHub', desc: 'Contribua com projetos open source', link: '#', color: 'text-gray-400' },
            { icon: Twitter, title: 'Twitter', desc: 'Novidades e atualizações', link: '#', color: 'text-blue-400' },
            { icon: Users, title: 'Fórum', desc: 'Discussões e perguntas', link: '#', color: 'text-green-400' },
            { icon: HelpCircle, title: 'FAQ', desc: 'Perguntas frequentes', link: '#', color: 'text-yellow-400' },
            { icon: MessageSquare, title: 'Blog', desc: 'Tutoriais e artigos', link: '/blog', color: 'text-primary-400' },
          ].map((item) => (
            <Link
              key={item.title}
              href={item.link}
              className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-8 hover:border-primary-500/50 transition-all text-center"
            >
              <item.icon className={`w-12 h-12 ${item.color} mx-auto mb-4`} />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{item.title}</h3>
              <p className="text-gray-600 dark:text-gray-400">{item.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

import type { Metadata } from "next";
import "./globals.css";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { LanguageProvider } from "@/contexts/LanguageContext";

export const metadata: Metadata = {
  title: "Quark Cloud - Hospedagem Cloud de Alta Performance no Brasil",
  description: "Implante sua infraestrutura cloud em 55 segundos. Performance 3x superior, suporte 24/7 em português e migração gratuita.",
  keywords: "cloud hosting, vps brasil, servidor dedicado, hospedagem gerenciada, wordpress hosting",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="bg-white dark:bg-gray-950 text-gray-900 dark:text-white antialiased">
        <ThemeProvider>
          <LanguageProvider>
            <Navigation />
            <main className="min-h-screen">
              {children}
            </main>
            <Footer />
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}

'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Calendar, Clock, ArrowRight, Search } from 'lucide-react';

export default function BlogPage() {
  const posts = [
    {
      title: 'Como migrar sua aplicação para a nuvem em 5 passos',
      excerpt: 'Guia completo para migrar suas aplicações legadas para infraestrutura cloud moderna sem downtime.',
      category: 'Tutorial',
      date: '23 Out 2025',
      readTime: '8 min',
      image: '🚀',
      slug: 'migrar-aplicacao-nuvem',
    },
    {
      title: 'Melhores práticas de segurança para servidores cloud',
      excerpt: 'Aprenda a configurar firewalls, SSL/TLS e proteger seus servidores contra ataques comuns.',
      category: 'Segurança',
      date: '20 Out 2025',
      readTime: '12 min',
      image: '🔒',
      slug: 'seguranca-servidores-cloud',
    },
    {
      title: 'Kubernetes vs Docker: Qual escolher para seu projeto?',
      excerpt: 'Comparação detalhada entre orquestradores de containers e quando usar cada um.',
      category: 'DevOps',
      date: '18 Out 2025',
      readTime: '10 min',
      image: '🐳',
      slug: 'kubernetes-vs-docker',
    },
    {
      title: 'Otimizando performance de banco de dados PostgreSQL',
      excerpt: 'Técnicas avançadas de tuning para extrair máxima performance do seu PostgreSQL em produção.',
      category: 'Database',
      date: '15 Out 2025',
      readTime: '15 min',
      image: '🗄️',
      slug: 'otimizar-postgresql',
    },
    {
      title: 'Deploy automatizado com GitHub Actions e Quark Cloud',
      excerpt: 'Configure CI/CD completo para deployar automaticamente suas aplicações.',
      category: 'CI/CD',
      date: '12 Out 2025',
      readTime: '7 min',
      image: '⚙️',
      slug: 'deploy-github-actions',
    },
    {
      title: 'Monitoramento de aplicações com Prometheus e Grafana',
      excerpt: 'Setup completo de stack de observabilidade para monitorar suas aplicações em tempo real.',
      category: 'Monitoring',
      date: '10 Out 2025',
      readTime: '11 min',
      image: '📊',
      slug: 'monitoring-prometheus-grafana',
    },
  ];

  const categories = ['Todos', 'Tutorial', 'Segurança', 'DevOps', 'Database', 'CI/CD', 'Monitoring'];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-gray-950">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Blog <span className="gradient-text">Quark Cloud</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Tutoriais, guias e melhores práticas sobre cloud, DevOps e infraestrutura.
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar artigos..."
                className="w-full bg-gray-900 border border-gray-800 rounded-lg pl-12 pr-4 py-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
              />
            </div>
          </div>
        </motion.div>

        {/* Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((category) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                category === 'Todos'
                  ? 'bg-primary-500 text-white'
                  : 'bg-gray-900 border border-gray-800 text-gray-400 hover:text-white hover:border-gray-700'
              }`}
            >
              {category}
            </button>
          ))}
        </motion.div>

        {/* Blog Posts Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {posts.map((post, index) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="group bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-gray-700 transition-all duration-300 hover:shadow-xl hover:shadow-primary-500/5"
            >
              <div className="p-6">
                <div className="text-6xl mb-4">{post.image}</div>
                
                <div className="flex items-center space-x-4 mb-4 text-sm">
                  <span className="bg-primary-500/10 text-primary-400 px-3 py-1 rounded-full font-medium">
                    {post.category}
                  </span>
                  <div className="flex items-center text-gray-500">
                    <Calendar className="w-4 h-4 mr-1" />
                    {post.date}
                  </div>
                </div>

                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-primary-400 transition-colors">
                  {post.title}
                </h3>
                
                <p className="text-gray-400 mb-4 line-clamp-2">
                  {post.excerpt}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-500 text-sm">
                    <Clock className="w-4 h-4 mr-1" />
                    {post.readTime} de leitura
                  </div>
                  <ArrowRight className="w-5 h-5 text-primary-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>
          ))}
        </motion.div>

        {/* Newsletter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-20 bg-gradient-to-br from-primary-500/10 to-primary-600/5 border border-primary-500/20 rounded-2xl p-12 text-center"
        >
          <h2 className="text-3xl font-bold text-white mb-4">
            Receba novos artigos por email
          </h2>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Assine nossa newsletter e receba tutoriais, dicas e novidades sobre cloud computing diretamente na sua caixa de entrada.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="seu@email.com"
              className="flex-1 bg-gray-950 border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
            <button className="bg-primary-500 hover:bg-primary-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:shadow-xl hover:shadow-primary-500/50">
              Assinar
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

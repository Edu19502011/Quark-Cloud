'use client';

import { motion } from 'framer-motion';
import { 
  Zap, 
  HeadphonesIcon, 
  RefreshCw, 
  TrendingUp,
  Shield,
  Globe,
  Award,
  FileCheck
} from 'lucide-react';
import Link from 'next/link';

export default function DiferenciaisPage() {
  const differentials = [
    {
      icon: TrendingUp,
      title: 'Performance Real',
      subtitle: 'Benchmarks transparentes e verificáveis',
      description: 'Não é só marketing - nossos números são reais e verificáveis.',
      metrics: [
        { label: 'I/O de Disco (IOPS)', value: '95.000', comparison: '3x mais rápido que ShardCloud' },
        { label: 'Throughput de Rede', value: '10 Gbps', comparison: '2x mais rápido que DigitalOcean' },
        { label: 'Latência Interna', value: '<1ms', comparison: 'Melhor da categoria' },
      ],
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
    },
    {
      icon: HeadphonesIcon,
      title: 'Suporte 24/7 em Português',
      subtitle: 'Time técnico especializado disponível sempre',
      description: 'Atendimento por profissionais qualificados, não chatbots.',
      metrics: [
        { label: 'Tempo médio de resposta', value: '5 minutos', comparison: 'Via chat, ticket ou telefone' },
        { label: 'Taxa de resolução', value: '94%', comparison: 'No primeiro contato' },
        { label: 'Satisfação do cliente', value: '4.9/5', comparison: 'Baseado em 2.500+ avaliações' },
      ],
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
    },
    {
      icon: RefreshCw,
      title: 'Migração Gratuita',
      subtitle: 'Nossa equipe faz todo o trabalho por você',
      description: 'Sem custo adicional e com garantia de zero downtime.',
      metrics: [
        { label: 'Custo', value: 'R$ 0', comparison: 'Completamente gratuito' },
        { label: 'Downtime', value: '0 minutos', comparison: 'Migração sem interrupção' },
        { label: 'Suporte dedicado', value: 'Incluído', comparison: 'Do início ao fim' },
      ],
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
    },
    {
      icon: Shield,
      title: 'Uptime e SLA',
      subtitle: 'Garantia contratual de disponibilidade',
      description: 'Não é uma promessa vazia - está no contrato.',
      metrics: [
        { label: 'SLA garantido', value: '99.99%', comparison: 'Com compensação automática' },
        { label: 'Uptime histórico', value: '99.994%', comparison: 'Últimos 24 meses' },
        { label: 'Tempo de recuperação', value: '<5min', comparison: 'Em caso de falhas' },
      ],
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
    },
    {
      icon: Globe,
      title: 'Infraestrutura Global',
      subtitle: 'Data centers estrategicamente posicionados',
      description: 'Presença no Brasil, EUA e Europa para latência mínima.',
      metrics: [
        { label: 'São Paulo', value: '< 10ms', comparison: 'Latência média Brasil' },
        { label: 'Miami', value: '< 40ms', comparison: 'Latência média Américas' },
        { label: 'Frankfurt', value: '< 150ms', comparison: 'Latência média Europa' },
      ],
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-400/10',
    },
    {
      icon: Award,
      title: 'Certificações e Conformidade',
      subtitle: 'Segurança e compliance em primeiro lugar',
      description: 'Certificações internacionais reconhecidas.',
      metrics: [
        { label: 'ISO 27001', value: 'Certificado', comparison: 'Segurança da informação' },
        { label: 'SOC 2 Type II', value: 'Certificado', comparison: 'Controles organizacionais' },
        { label: 'LGPD', value: 'Compliant', comparison: 'Proteção de dados brasileira' },
      ],
      color: 'text-red-400',
      bgColor: 'bg-red-400/10',
    },
  ];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Por que escolher a{' '}
            <span className="gradient-text">Quark Cloud</span>?
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Não somos apenas mais um provedor de cloud. Somos diferentes onde realmente importa.
          </p>
        </motion.div>

        <div className="space-y-12">
          {differentials.map((differential, index) => {
            const Icon = differential.icon;
            return (
              <motion.div
                key={differential.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-900 border border-gray-800 rounded-2xl p-8 hover:border-gray-700 transition-all duration-300"
              >
                <div className="grid lg:grid-cols-2 gap-8">
                  <div>
                    <div className={`${differential.bgColor} w-16 h-16 rounded-xl flex items-center justify-center mb-4`}>
                      <Icon className={`w-8 h-8 ${differential.color}`} />
                    </div>
                    <h2 className="text-3xl font-bold text-white mb-2">
                      {differential.title}
                    </h2>
                    <p className={`${differential.color} font-medium mb-4`}>
                      {differential.subtitle}
                    </p>
                    <p className="text-gray-400 text-lg leading-relaxed">
                      {differential.description}
                    </p>
                  </div>

                  <div className="space-y-4">
                    {differential.metrics.map((metric) => (
                      <div
                        key={metric.label}
                        className="bg-gray-950 border border-gray-800 rounded-lg p-4"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <span className="text-gray-400 text-sm">{metric.label}</span>
                          <span className={`text-2xl font-bold ${differential.color}`}>
                            {metric.value}
                          </span>
                        </div>
                        <p className="text-gray-500 text-xs">{metric.comparison}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16 bg-gradient-to-br from-primary-500/10 to-primary-600/5 border border-primary-500/20 rounded-2xl p-12 text-center"
        >
          <FileCheck className="w-16 h-16 text-primary-400 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white mb-4">
            Pronto para experimentar a diferença?
          </h2>
          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Ganhe R$ 100 em créditos para testar nossa infraestrutura por 30 dias. 
            Sem compromisso, sem cartão de crédito.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/signup"
              className="inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:shadow-xl hover:shadow-primary-500/50"
            >
              Começar Gratuitamente
            </Link>
            <Link
              href="/precos"
              className="inline-flex items-center justify-center border border-gray-700 hover:border-gray-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:bg-gray-900"
            >
              Ver Preços
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Check, ArrowRight } from 'lucide-react';

export default function PricingPage() {
  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Preços <span className="gradient-text">transparentes</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Pague apenas pelo que usar. Sem taxas ocultas, sem contratos longos. Cancele quando quiser.
          </p>
        </motion.div>

        <PricingCalculator />
        <PricingPlans />
      </div>
    </div>
  );
}

function PricingCalculator() {
  const [cpu, setCpu] = useState(2);
  const [ram, setRam] = useState(4);
  const [storage, setStorage] = useState(80);

  const calculatePrice = () => {
    const cpuPrice = cpu * 12;
    const ramPrice = ram * 6;
    const storagePrice = storage * 0.15;
    return cpuPrice + ramPrice + storagePrice;
  };

  const monthlyPrice = calculatePrice();
  const hourlyPrice = monthlyPrice / 730;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
      className="bg-gray-900 border border-gray-800 rounded-2xl p-8 mb-16"
    >
      <h2 className="text-2xl font-bold text-white mb-6">Calculadora de Preços Interativa</h2>
      
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          {/* CPU Slider */}
          <div>
            <div className="flex justify-between mb-2">
              <label className="text-white font-medium">CPU (vCores)</label>
              <span className="text-primary-400 font-bold">{cpu} vCores</span>
            </div>
            <input
              type="range"
              min="1"
              max="64"
              value={cpu}
              onChange={(e) => setCpu(Number(e.target.value))}
              className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-primary-500"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>1</span>
              <span>64</span>
            </div>
          </div>

          {/* RAM Slider */}
          <div>
            <div className="flex justify-between mb-2">
              <label className="text-white font-medium">RAM</label>
              <span className="text-primary-400 font-bold">{ram} GB</span>
            </div>
            <input
              type="range"
              min="1"
              max="512"
              value={ram}
              onChange={(e) => setRam(Number(e.target.value))}
              className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-primary-500"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>1 GB</span>
              <span>512 GB</span>
            </div>
          </div>

          {/* Storage Slider */}
          <div>
            <div className="flex justify-between mb-2">
              <label className="text-white font-medium">Armazenamento SSD NVMe</label>
              <span className="text-primary-400 font-bold">{storage} GB</span>
            </div>
            <input
              type="range"
              min="20"
              max="4000"
              step="20"
              value={storage}
              onChange={(e) => setStorage(Number(e.target.value))}
              className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-primary-500"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>20 GB</span>
              <span>4 TB</span>
            </div>
          </div>
        </div>

        {/* Price Display */}
        <div className="bg-gradient-to-br from-primary-500/10 to-primary-600/5 border border-primary-500/20 rounded-xl p-8">
          <div className="text-center mb-6">
            <div className="text-gray-400 mb-2">Custo Estimado</div>
            <div className="text-5xl font-bold text-white mb-2">
              R$ {monthlyPrice.toFixed(2)}
            </div>
            <div className="text-gray-400">por mês</div>
            <div className="text-sm text-gray-500 mt-2">
              ou R$ {hourlyPrice.toFixed(4)}/hora
            </div>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex items-center text-sm text-gray-300">
              <Check className="w-4 h-4 text-green-400 mr-2" />
              Backup automático diário incluído
            </div>
            <div className="flex items-center text-sm text-gray-300">
              <Check className="w-4 h-4 text-green-400 mr-2" />
              Proteção DDoS incluída
            </div>
            <div className="flex items-center text-sm text-gray-300">
              <Check className="w-4 h-4 text-green-400 mr-2" />
              Suporte 24/7 em português
            </div>
            <div className="flex items-center text-sm text-gray-300">
              <Check className="w-4 h-4 text-green-400 mr-2" />
              Firewall gerenciado
            </div>
          </div>

          <Link
            href="/signup"
            className="w-full inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200"
          >
            Começar Agora
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

function PricingPlans() {
  const plans = [
    {
      name: 'Starter',
      description: 'Para projetos pessoais e testes',
      price: '49',
      features: [
        '2 vCPU',
        '4 GB RAM',
        '80 GB SSD NVMe',
        '2 TB Transferência',
        'Backup diário',
        'Suporte via ticket',
      ],
      cta: 'Começar',
      popular: false,
    },
    {
      name: 'Professional',
      description: 'Para aplicações em produção',
      price: '149',
      features: [
        '4 vCPU',
        '16 GB RAM',
        '320 GB SSD NVMe',
        '6 TB Transferência',
        'Backup a cada 6h',
        'Suporte prioritário 24/7',
        'Snapshots ilimitados',
        'Firewall avançado',
      ],
      cta: 'Começar',
      popular: true,
    },
    {
      name: 'Enterprise',
      description: 'Para grandes volumes e SLA dedicado',
      price: 'Custom',
      features: [
        'CPU e RAM customizados',
        'Armazenamento ilimitado',
        'Transferência ilimitada',
        'Backup contínuo',
        'SLA 99.99%',
        'Suporte dedicado',
        'Migração assistida',
        'Conformidade LGPD',
      ],
      cta: 'Falar com Vendas',
      popular: false,
    },
  ];

  return (
    <div className="grid md:grid-cols-3 gap-8">
      {plans.map((plan, index) => (
        <motion.div
          key={plan.name}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 + index * 0.1 }}
          className={`relative bg-gray-900 border ${
            plan.popular ? 'border-primary-500 shadow-xl shadow-primary-500/10' : 'border-gray-800'
          } rounded-2xl p-8`}
        >
          {plan.popular && (
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                Mais Popular
              </span>
            </div>
          )}

          <div className="mb-6">
            <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
            <p className="text-gray-400 text-sm">{plan.description}</p>
          </div>

          <div className="mb-6">
            {plan.price === 'Custom' ? (
              <div className="text-4xl font-bold text-white">Personalizado</div>
            ) : (
              <div>
                <span className="text-gray-400 text-lg">R$</span>
                <span className="text-4xl font-bold text-white">{plan.price}</span>
                <span className="text-gray-400">/mês</span>
              </div>
            )}
          </div>

          <ul className="space-y-3 mb-8">
            {plan.features.map((feature) => (
              <li key={feature} className="flex items-start text-gray-300 text-sm">
                <Check className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                {feature}
              </li>
            ))}
          </ul>

          <Link
            href={plan.price === 'Custom' ? '/contato' : '/signup'}
            className={`w-full inline-flex items-center justify-center px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
              plan.popular
                ? 'bg-primary-500 hover:bg-primary-600 text-white'
                : 'border border-gray-700 hover:border-gray-600 text-white hover:bg-gray-800'
            }`}
          >
            {plan.cta}
          </Link>
        </motion.div>
      ))}
    </div>
  );
}

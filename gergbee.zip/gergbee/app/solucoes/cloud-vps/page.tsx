'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Server, Zap, Shield, ArrowRight, Check, Cpu, HardDrive, Network } from 'lucide-react';

export default function CloudVPSPage() {
  const features = [
    'SSDs NVMe Gen4 de última geração',
    'CPUs AMD EPYC de alta performance',
    'Rede 10 Gbps com baixa latência',
    'IPv4 e IPv6 dedicados',
    'Snapshots ilimitados',
    'Backup automático diário',
    'Firewall gerenciado',
    'Proteção DDoS incluída',
    'Painel de controle intuitivo',
    'API completa e documentada',
    'Migração gratuita assistida',
    'Suporte 24/7 em português',
  ];

  const plans = [
    {
      name: 'VPS Basic',
      price: '49',
      specs: {
        cpu: '2 vCPU',
        ram: '4 GB',
        storage: '80 GB NVMe',
        bandwidth: '2 TB',
      },
      features: ['Backup diário', 'Firewall', 'IPv4 dedicado', 'Suporte 24/7'],
    },
    {
      name: 'VPS Pro',
      price: '99',
      specs: {
        cpu: '4 vCPU',
        ram: '8 GB',
        storage: '160 GB NVMe',
        bandwidth: '4 TB',
      },
      features: ['Backup a cada 6h', 'Firewall avançado', 'IPv4 + IPv6', 'Suporte prioritário', 'Snapshots ilimitados'],
      popular: true,
    },
    {
      name: 'VPS Premium',
      price: '199',
      specs: {
        cpu: '8 vCPU',
        ram: '16 GB',
        storage: '320 GB NVMe',
        bandwidth: '8 TB',
      },
      features: ['Backup contínuo', 'DDoS Premium', 'IPs dedicados', 'SLA 99.99%', 'Gerente de conta'],
    },
  ];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-gray-950">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center space-x-2 bg-primary-500/10 border border-primary-500/20 rounded-full px-4 py-2 mb-6">
            <Server className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-primary-300 font-medium">Cloud VPS</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Servidores VPS <span className="gradient-text">Cloud</span>
          </h1>
          
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Servidores virtuais de alta performance com SSDs NVMe, CPUs AMD EPYC e rede de 10 Gbps. 
            Deploy em 55 segundos.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/signup"
              className="inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:shadow-xl hover:shadow-primary-500/50"
            >
              Começar Agora
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <Link
              href="/precos"
              className="inline-flex items-center justify-center border border-gray-700 hover:border-gray-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:bg-gray-900"
            >
              Ver Todos os Planos
            </Link>
          </div>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid md:grid-cols-3 gap-8 mb-20"
        >
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
            <div className="bg-primary-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Cpu className="w-6 h-6 text-primary-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Performance Extrema</h3>
            <p className="text-gray-400">
              CPUs AMD EPYC de última geração com clock de até 3.7 GHz para máxima performance.
            </p>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
            <div className="bg-green-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <HardDrive className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Armazenamento NVMe</h3>
            <p className="text-gray-400">
              SSDs NVMe Gen4 com I/O de até 95.000 IOPS para aplicações de alta demanda.
            </p>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
            <div className="bg-blue-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Network className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Rede Premium</h3>
            <p className="text-gray-400">
              Conectividade de 10 Gbps com múltiplos uplinks para máxima disponibilidade.
            </p>
          </div>
        </motion.div>

        {/* All Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="bg-gray-900 border border-gray-800 rounded-2xl p-8 mb-20"
        >
          <h2 className="text-3xl font-bold text-white mb-8 text-center">
            Tudo que você precisa, incluído
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            {features.map((feature) => (
              <div key={feature} className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Pricing Plans */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-12 text-center">
            Planos populares de VPS Cloud
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative bg-gray-900 border ${
                  plan.popular ? 'border-primary-500' : 'border-gray-800'
                } rounded-2xl p-8`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Mais Popular
                    </span>
                  </div>
                )}

                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">R$ {plan.price}</span>
                  <span className="text-gray-400">/mês</span>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">CPU</span>
                    <span className="text-white font-medium">{plan.specs.cpu}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">RAM</span>
                    <span className="text-white font-medium">{plan.specs.ram}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Armazenamento</span>
                    <span className="text-white font-medium">{plan.specs.storage}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Transferência</span>
                    <span className="text-white font-medium">{plan.specs.bandwidth}</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start text-sm text-gray-300">
                      <Check className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Link
                  href="/signup"
                  className={`w-full inline-flex items-center justify-center px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                    plan.popular
                      ? 'bg-primary-500 hover:bg-primary-600 text-white'
                      : 'border border-gray-700 hover:border-gray-600 text-white hover:bg-gray-800'
                  }`}
                >
                  Começar Agora
                </Link>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}

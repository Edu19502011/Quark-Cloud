'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Server, Database, Cpu, ArrowRight, Check } from 'lucide-react';

export default function ServidoresDedicadosPage() {
  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-white">
            Servidores <span className="gradient-text">Dedicados</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-8">
            Hardware exclusivo de última geração para máxima performance e controle total.
          </p>
          <Link
            href="/contato"
            className="inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold"
          >
            Solicitar Orçamento
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            { icon: Cpu, title: 'Intel Xeon ou AMD EPYC', desc: 'Processadores de última geração' },
            { icon: Database, title: 'Até 2TB RAM', desc: 'Memória ECC para estabilidade' },
            { icon: Server, title: 'NVMe RAID', desc: 'Armazenamento ultra-rápido' },
          ].map((item) => (
            <div key={item.title} className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6">
              <item.icon className="w-12 h-12 text-primary-400 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{item.title}</h3>
              <p className="text-gray-600 dark:text-gray-400">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

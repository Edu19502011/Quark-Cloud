'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Code, Rocket, ArrowRight } from 'lucide-react';

export default function AplicacoesPage() {
  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-gray-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-white">
            Hospedagem de <span className="gradient-text">Aplicações</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-8">
            Deploy de aplicações Node.js, Python, Go, PHP e mais. Container-ready e com CI/CD integrado.
          </p>
          <Link
            href="/signup"
            className="inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold"
          >
            Começar Agora
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </motion.div>

        <div className="grid md:grid-cols-4 gap-6">
          {['Node.js', 'Python', 'Go', 'PHP', 'Ruby', 'Java', 'Docker', '.NET'].map((tech) => (
            <div key={tech} className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg p-6 text-center">
              <Code className="w-8 h-8 text-primary-400 mx-auto mb-3" />
              <h3 className="font-bold text-gray-900 dark:text-white">{tech}</h3>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

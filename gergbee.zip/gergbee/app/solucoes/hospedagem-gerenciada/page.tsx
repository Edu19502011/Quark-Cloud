'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Server, Zap, Shield, ArrowRight, Check, RefreshCw, Lock, Gauge } from 'lucide-react';

export default function HospedagemGerenciadaPage() {
  const features = [
    'WordPress otimizado e pré-configurado',
    'SSL/TLS grátis (Let\'s Encrypt)',
    'CDN integrado para performance',
    'Backup automático diário',
    'Atualizações automáticas de segurança',
    'Cache inteligente (Redis/Memcached)',
    'Proteção contra malware',
    'Firewall de aplicação web (WAF)',
    'Staging environment incluído',
    'Git deployment integrado',
    'One-click restore',
    'Suporte especializado 24/7',
  ];

  const platforms = [
    {
      name: 'WordPress',
      icon: '🚀',
      description: 'Hospedagem otimizada para WordPress com cache e CDN',
    },
    {
      name: 'Magento',
      icon: '🛒',
      description: 'E-commerce de alta performance com escalabilidade',
    },
    {
      name: 'Drupal',
      icon: '📄',
      description: 'CMS enterprise com segurança e performance',
    },
    {
      name: 'Joomla',
      icon: '🌐',
      description: 'Plataforma flexível com suporte completo',
    },
  ];

  const plans = [
    {
      name: 'Starter',
      price: '79',
      sites: '1 site',
      visitors: '25k visitas/mês',
      storage: '20 GB SSD',
      features: ['SSL grátis', 'Backup diário', 'CDN global', 'Suporte 24/7'],
    },
    {
      name: 'Business',
      price: '149',
      sites: '3 sites',
      visitors: '100k visitas/mês',
      storage: '50 GB SSD',
      features: ['Tudo do Starter', 'Staging', 'Cache avançado', 'Prioridade no suporte'],
      popular: true,
    },
    {
      name: 'Enterprise',
      price: '299',
      sites: 'Ilimitado',
      visitors: '500k+ visitas/mês',
      storage: '200 GB SSD',
      features: ['Tudo do Business', 'WAF dedicado', 'Gerente de conta', 'SLA 99.99%'],
    },
  ];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-gray-950">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center space-x-2 bg-primary-500/10 border border-primary-500/20 rounded-full px-4 py-2 mb-6">
            <Server className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-primary-300 font-medium">Hospedagem Gerenciada</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-white">
            Hospedagem <span className="gradient-text">Gerenciada</span>
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-8">
            Foque no seu negócio enquanto cuidamos de toda infraestrutura, segurança e performance 
            da sua aplicação web.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/signup"
              className="inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:shadow-xl hover:shadow-primary-500/50"
            >
              Começar Agora
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <Link
              href="/contato"
              className="inline-flex items-center justify-center border border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600 text-gray-900 dark:text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 hover:bg-gray-50 dark:hover:bg-gray-900"
            >
              Falar com Especialista
            </Link>
          </div>
        </motion.div>

        {/* Platform Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid md:grid-cols-4 gap-6 mb-20"
        >
          {platforms.map((platform) => (
            <div key={platform.name} className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6 text-center hover:border-primary-500/50 transition-all duration-300">
              <div className="text-5xl mb-4">{platform.icon}</div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{platform.name}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{platform.description}</p>
            </div>
          ))}
        </motion.div>

        {/* Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="grid md:grid-cols-3 gap-8 mb-20"
        >
          <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6">
            <div className="bg-primary-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Gauge className="w-6 h-6 text-primary-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Performance Máxima</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Cache inteligente, CDN global e otimizações específicas para cada plataforma garantem velocidade extrema.
            </p>
          </div>

          <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6">
            <div className="bg-green-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Lock className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Segurança Total</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Firewall WAF, proteção DDoS, SSL automático e monitoramento 24/7 contra ameaças.
            </p>
          </div>

          <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6">
            <div className="bg-blue-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <RefreshCw className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Sempre Atualizado</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Atualizações automáticas de segurança e versões mantêm seu site sempre protegido.
            </p>
          </div>
        </motion.div>

        {/* Features List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8 mb-20"
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Tudo incluído, sem surpresas
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            {features.map((feature) => (
              <div key={feature} className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-gray-700 dark:text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Pricing */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12 text-center">
            Escolha o plano ideal
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative bg-gray-50 dark:bg-gray-900 border ${
                  plan.popular ? 'border-primary-500' : 'border-gray-200 dark:border-gray-800'
                } rounded-2xl p-8`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Mais Popular
                    </span>
                  </div>
                )}

                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">R$ {plan.price}</span>
                  <span className="text-gray-600 dark:text-gray-400">/mês</span>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Sites: </span>
                    <span className="text-gray-900 dark:text-white font-medium">{plan.sites}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Visitantes: </span>
                    <span className="text-gray-900 dark:text-white font-medium">{plan.visitors}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Armazenamento: </span>
                    <span className="text-gray-900 dark:text-white font-medium">{plan.storage}</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start text-sm text-gray-700 dark:text-gray-300">
                      <Check className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Link
                  href="/signup"
                  className={`w-full inline-flex items-center justify-center px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                    plan.popular
                      ? 'bg-primary-500 hover:bg-primary-600 text-white'
                      : 'border border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600 text-gray-900 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}
                >
                  Começar Agora
                </Link>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
